#include <stdio.h>
#include "hellomake.h"

void myPrintHelloMake(void) {

printf("Hello Makefile!\n");

return;

}
