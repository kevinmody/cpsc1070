//
//  readwrite.h
//  
//
//  Created by Donald House on 9/8/19.
//

#ifndef readwrite_h
#define readwrite_h

int read(void);
void write(int num);

#endif /* readwrite_h */
