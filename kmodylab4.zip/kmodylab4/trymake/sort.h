//
//  sort.h
//  
//
//  Created by Donald House on 9/8/19.
//

#ifndef sort_h
#define sort_h

void sort(int table[], int n);

#endif /* sort_h */
